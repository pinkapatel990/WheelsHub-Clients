

const router = require('express').Router();


router.use('/api/v1', require('./api'));


module.exports = router;
